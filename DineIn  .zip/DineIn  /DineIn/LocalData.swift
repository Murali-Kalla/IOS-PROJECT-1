//
//  LocalData.swift
//  DineIn
//
//  Created by Kalla,Muralidhar Reddy on 4/28/22.
//

import Foundation


struct LocalData {
    
    static let isLocal = true
    
    /// List of categories the app should return
    static let categories = [
        "Appetizers",
        "Main Course",
        "Beverages"
    ]
    
    static let menuItems = [
        MenuItem(
            id: 1,
            name: "Vegetable Samosas",
            description: "A traditional, crispy pastry stuffed with mashed potatoes, green peas and light savory spices.",
            price: 4.99,
            category: "Appetizers",
            imageURL: URL(fileURLWithPath: "vegetablesamosas")
            ),
            
        MenuItem(
            id: 2,
            name: "Bhel Puri",
            description: "Crispy popped rice, mixed with diced onion, tomato, spices, nuts, chickpeas, tamarind and fresh mint chutney.",
            price: 6.99,
            category: "Appetizers",
            imageURL: URL(fileURLWithPath: "bhelpuri")
            
        ),
        MenuItem(
            id: 3,
            name: "Paneer Pakora",
            description: "Our house Paneer in a lightly spiced chickpea flour batter which is deep fried to give it a crunchy yet soft finish.",
            price: 12.99,
            category: "Appetizers",
            imageURL: URL(fileURLWithPath: "paneerpakora")
            
        ),
        
        MenuItem(
            id: 4,
            name: "Samosa Chat",
            description: "Samosa turned inside out, crushed samosa served with chickpeas, onion and our combination of house chutneys to give you a street food from home!",
            price: 6.99,
            category: "Appetizers",
            imageURL: URL(fileURLWithPath: "samosachat")
            
        ),
        
        MenuItem(
            id: 5,
            name: "Chilli Panner",
            description: "Fresh restaurant made cheese with a spicy twist. A combination of pan-fried bell-pepper, onion and cheese in a fusion sauce that best represents North Indian appetizers.",
            price: 13.99,
            category: "Appetizers",
            imageURL: URL(fileURLWithPath: "chillipaneer")
            
        ),
        
        MenuItem(
            id: 6,
            name: "Vegetable Curry",
            description: "Combination of mixed vegetables,herbs and spices.",
            price: 12.99,
            category: "Main Course",
            imageURL: URL(fileURLWithPath: "vegetablecurry")
            
        ),
        MenuItem(
            id: 7,
            name: "Chana Masala ",
            description: "Chickpeas cooked in exotic spices with sauce.",
            price: 12.99,
            category: "Main Course",
            imageURL: URL(fileURLWithPath: "chanamasala")
        ),
        MenuItem(
            id: 8,
            name: "Dal Tadka",
            description: "Yellow lentils topped with popped mustard seeds.",
            price:13.99,
            category: "Main Course",
            imageURL: URL(fileURLWithPath: "daltadka")
        ),
        
        MenuItem(
            id: 9,
            name: "Palak Paneer",
            description: "Garden spinach finished with subtle spices and cheese.",
            price: 14.99,
            category: "Main Course",
            imageURL: URL(fileURLWithPath: "palakpaneer")
        ),
        
        MenuItem(
            id: 10,
            name: "Kadai Paneer",
            description: "A combination of spicy cheese and vegetables.",
            price: 15.99,
            category: "Main Course",
            imageURL: URL(fileURLWithPath: "kadaipaneer")
        ),
        
        MenuItem(
            id: 11,
            name: "Mango Lassi",
            description: "Mango yogurt smoothly blended with sweet.",
            price: 3.99,
            category: "Beverages",
            imageURL: URL(fileURLWithPath: "mangolassi")
            
        ),
        MenuItem(
            id: 12,
            name: "Madras Coffee",
            description: "A combination of spicy cheese and vegetables.",
            price: 4.99,
            category: "Beverages",
            imageURL: URL(fileURLWithPath: "madrascoffee")
           
        ),
        MenuItem(
            id: 13,
            name: "Masala Tea",
            description: "(hot) Tea with Indian spices.",
            price: 3.99,
            category: "Beverages",
            imageURL: URL(fileURLWithPath: "masalatea")
            
        ),
        MenuItem(
            id: 14,
            name: "Thumbs Up",
            description: "A combination of spicy cheese and vegetables.",
            price: 3.99,
            category: "Beverages",
            imageURL: URL(fileURLWithPath: "thumbsup")
            
        ),
        
        MenuItem(
            id: 15,
            name: "Ice Tea",
            description: "Iced tea (or ice tea) is a form of cold tea. Though usually served in a glass with ice, it can refer to any tea that has been chilled or cooled",
            price: 4.99,
            category: "Beverages",
            imageURL: URL(fileURLWithPath: "icetea")
            
        ),
        
        
    ]
}
