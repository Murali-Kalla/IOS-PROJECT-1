//
//  AddToOrderDelegate.swift
//  DineIn
//
//  Created by Kalla,Muralidhar Reddy on 4/28/22.
//



protocol AddToOrderDelegate {
    /// Called when menu item is added
    func added(menuItem: MenuItem)
}
