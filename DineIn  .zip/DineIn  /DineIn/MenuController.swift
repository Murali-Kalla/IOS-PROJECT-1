//
//  MenuController.swift
//  DineIn
//
//  Created by Kalla,Muralidhar Reddy on 4/28/22.
//

import Foundation

import UIKit

// Controller with all the networking code
class MenuController {
    /// Used to share MenuController across all view controllers in the app
    
    static let shared = MenuController()
    
    
    func fetchCategories(completion: @escaping ([String]?) -> Void) {
        
        
        if LocalData.isLocal {
            completion(LocalData.categories)
            return
        }
        
       
    }
    
    func fetchMenuItems(categoryName: String = "", completion: @escaping([MenuItem]?) -> Void) {
        
      
        if LocalData.isLocal {
            completion(LocalData.menuItems.filter { $0.category == categoryName || categoryName.isEmpty })
            return
        }
        
       
    }
    
    
    func submitOrder(menuIds: [Int], completion: @escaping (Int?) -> Void) {
        
       
        if LocalData.isLocal {
            completion(5 * menuIds.count)
            return
        }
        
      
    }
    
    
    func fetchImage(url: URL, completion: @escaping (UIImage?) -> Void) {
        
      
        if LocalData.isLocal {
            completion(UIImage(named: url.relativeString))
            return
        }
        
        
    }
        
}
