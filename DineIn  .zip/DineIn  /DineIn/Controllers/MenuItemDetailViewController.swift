//
//  MenuItemDetailViewController.swift
//  DineIn
//
//  Created by Kalla,Muralidhar Reddy on 4/3/22.
//

import UIKit

class MenuItemDetailViewController: UIViewController {
    
    
    var menuItem: MenuItem!
    
    /// Delegate to notify that the Add To Order button was tapped
    var delegate : AddToOrderDelegate?
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UILabel!

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var addToOrderButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // update the screen with menuItem values
        updateUI()
        
        // setup the delegate
        setupDelegate()
    }
    
    
    
    @IBAction func addToOrderButtonPressed(_ sender: UIButton) {
        
        // quick bounce animation after the button is pressed
        UIView.animate(withDuration: 0.3) {
            self.addToOrderButton.transform = CGAffineTransform(scaleX: 3, y: 3)
            self.addToOrderButton.transform = CGAffineTransform(scaleX: 1, y: 1)
        }
        
        // notify the delegate that the item was added to the order
        delegate?.added(menuItem: menuItem)
        
    }
    
    func updateUI() {
        // the name of the food
        titleLabel.text = menuItem.name
        
        // food price
        priceLabel.text = String(format: "$%.2f", menuItem.price)
        
        // detailed food description
        descriptionLabel.text = menuItem.description
        
        // make button's corners round
        addToOrderButton.layer.cornerRadius = 5
        
        // get the image for the menu item
        MenuController.shared.fetchImage(url: menuItem.imageURL) { image in
            // check that we got the image loaded
            guard let image = image else { return }
            
            // assign the image to the image view in the main thread
            DispatchQueue.main.async {
                self.imageView.image = image
            }
        }
    }
    
    func setupDelegate() {
        // find order table view controller through navigation controller
        if let navController = tabBarController?.viewControllers?.last as? UINavigationController,
            let orderTableViewController = navController.viewControllers.first as? OrderTableViewController {
            delegate = orderTableViewController
        }
        
    }

}
