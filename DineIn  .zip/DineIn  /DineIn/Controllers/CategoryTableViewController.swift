//
//  CategoryTableViewController.swift
//  DineIn
//
//  Created by Kalla,Muralidhar Reddy on 4/3/22.
//

import UIKit

class CategoryTableViewController: UITableViewController {
    
    
    
    /// Names of the menu categories
    var categories = [String]()
    
    /// Array of menu items to be fetched
    var menuItems = [MenuItem]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load the menu for all categories
        MenuController.shared.fetchMenuItems() { (menuItems) in
            // if we indeed got the menu items
            if let menuItems = menuItems {
                // compose the list of categories
                for item in menuItems {
                    // get the item's category
                    let category = item.category
                    
                    // add category only if it was not added before
                    if !self.categories.contains(category) {
                        self.categories.append(category)
                    }
                }
                
                // remember the list of items
                self.menuItems = menuItems
                
                // update the table with categories
                self.updateUI(with: self.categories)
            }
        }
    }
    
   
    func updateUI(with categories: [String]) {
       
        DispatchQueue.main.async {
            // remember the list of categories to display in the table
            self.categories = categories
            
            // reload the categories table
            self.tableView.reloadData()
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // There is only one section — the list of categories
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // number of sections is equal to number of categories we have
        return categories.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // reuse a category prototype cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCellIdentifier", for: indexPath)

        // Configure the cell...
        configure(cell: cell, forItemAt: indexPath)

        return cell
    }
    
    
    func configure(cell: UITableViewCell, forItemAt indexPath: IndexPath) {
        // get the name of the category
        let categoryString = categories[indexPath.row]
        
        // make sure it is capitalized to clean up the appearance of categories
        cell.textLabel?.text = categoryString.capitalized
        
        // find the first item in the category for image fetching
        guard let menuItem = menuItems.first(where: { item in
            return item.category == categoryString
        }) else { return }
        
        // fetch the image
        MenuController.shared.fetchImage(url: menuItem.imageURL) { image in
            // check that the image was fetched successfully
            guard let image = image else { return }
            
            DispatchQueue.main.async {
                // get the current index path
                guard let currentIndexPath = self.tableView.indexPath(for: cell) else { return }
                
                // check if the cell was not yet recycled
                guard currentIndexPath == indexPath else { return }
                
                // set the thumbnail image
                cell.imageView?.image = image
                
                // fit the image to the cell
                self.fitImage(in: cell)
            }
        }
    }
    
    // adjust the cell height to make images look better
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    
    // Need to pass the name of the chosen category before showing the category menu
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // make sure the segue is from category to menu table view controllers
        if segue.identifier == "MenuSegue" {
            // we can safely downcast to MenuTableViewController
            let menuTableViewController = segue.destination as! MenuTableViewController
            
            // index in the category array is equal to the selected table row number
            let index = tableView.indexPathForSelectedRow!.row
            
            // store the name of the category in the destination menu table view controller
            menuTableViewController.category = categories[index]
        }
    }

}
